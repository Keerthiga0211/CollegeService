package com.tns.collegeservice;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.TestPropertySource;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = {
        "spring.datasource.url=jdbc:h2:mem:testdb",
        "spring.datasource.driverClassName=org.h2.Driver",
        "spring.datasource.username=sa",
        "spring.datasource.password="
})
class CollegeserviceApplicationTests {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @MockBean
    private CollegeCertificateService certificateService;

    @Test
    void contextLoads() {
    }

    @Test
    void testGetAllCertificates() {
        // given
        CollegeCertificate certificate = new CollegeCertificate("John Doe", "Spring Boot", "2023-09-01", "A");
        List<CollegeCertificate> allCertificates = Collections.singletonList(certificate);
        given(certificateService.getAllCertificates()).willReturn(allCertificates);

        // when
        ResponseEntity<CollegeCertificate[]> response = restTemplate.getForEntity("http://localhost:" + port + "/api/college-certificates", CollegeCertificate[].class);

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).hasSize(1).contains(certificate);
    }

    @Test
    void testGetCertificateById() {
        // given
        CollegeCertificate certificate = new CollegeCertificate("John Doe", "Spring Boot", "2023-09-01", "A");
        given(certificateService.getCertificate(1L)).willReturn(certificate);

        // when
        ResponseEntity<CollegeCertificate> response = restTemplate.getForEntity("http://localhost:" + port + "/api/college-certificates/1", CollegeCertificate.class);

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isEqualTo(certificate);
    }

    @Test
    void testCreateCertificate() {
        // given
        CollegeCertificate certificate = new CollegeCertificate("John Doe", "Spring Boot", "2023-09-01", "A");
        given(certificateService.createCertificate(certificate)).willReturn(certificate);

        // when
        ResponseEntity<CollegeCertificate> response = restTemplate.postForEntity("http://localhost:" + port + "/api/college-certificates", certificate, CollegeCertificate.class);

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isEqualTo(certificate);
    }

    @Test
    void testUpdateCertificate() {
        // given
        CollegeCertificate certificate = new CollegeCertificate("John Doe", "Spring Boot", "2023-09-01", "A+");
        given(certificateService.updateCertificate(1L, certificate)).willReturn(certificate);

        // when
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<CollegeCertificate> entity = new HttpEntity<>(certificate, headers);
        ResponseEntity<CollegeCertificate> response = restTemplate.exchange("http://localhost:" + port + "/api/college-certificates/1", HttpMethod.PUT, entity, CollegeCertificate.class);

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isEqualTo(certificate);
    }

    @Test
    void testDeleteCertificate() {
        // given
        CollegeCertificate certificate = new CollegeCertificate("John Doe", "Spring Boot", "2023-09-01", "A");
        given(certificateService.getCertificate(1L)).willReturn(certificate);

        // when
        ResponseEntity<Void> response = restTemplate.exchange("http://localhost:" + port + "/api/college-certificates/1", HttpMethod.DELETE, null, Void.class);

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    void testGetCertificatesByStudent() {
        // given
        CollegeCertificate certificate = new CollegeCertificate("John Doe", "Spring Boot", "2023-09-01", "A");
        List<CollegeCertificate> certificates = Collections.singletonList(certificate);
        given(certificateService.getCertificatesByStudent("John Doe")).willReturn(certificates);

        // when
        ResponseEntity<CollegeCertificate[]> response = restTemplate.getForEntity("http://localhost:" + port + "/api/college-certificates/student/John Doe", CollegeCertificate[].class);

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).hasSize(1).contains(certificate);
    }
}
