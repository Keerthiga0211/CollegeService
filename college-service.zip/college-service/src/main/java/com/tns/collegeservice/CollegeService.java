package com.tns.collegeservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class CollegeService {
    
    @Autowired
    private CollegeRepository repository;

    public List<College> getAllCertificates() {
        return repository.findAll();
    }

    public College getCertificate(Long id) {
        Optional<College> cert = repository.findById(id);
        return cert.orElse(null);
    }

    public College createCertificate(College certificate) {
        return repository.save(certificate);
    }

    public College updateCertificate(Long id, College certificate) {
        if (repository.existsById(id)) {
            certificate.setId(id);
            return repository.save(certificate);
        }
        return null;
    }

    public void deleteCertificate(Long id) {
        repository.deleteById(id);
    }

    public List<College> getCertificatesByStudent(String studentName) {
        return repository.findByStudentFullName(studentName);
    }
}
