package com.tns.collegeservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/colleges")
@CrossOrigin(origins = "http://localhost:4200")
public class CollegeController {

    @Autowired
    private CollegeService service;

    @GetMapping
    public List<College> getAllColleges() {
        return service.getAllColleges();
    }

    @GetMapping("/{id}")
    public ResponseEntity<College> getCollege(@PathVariable Long id) {
        College cert = service.getCollege(id);
        if (cert != null) {
            return ResponseEntity.ok(cert);
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public College createCollege(@RequestBody College certificate) {
        return service.createCollege(certificate);
    }

    @PutMapping("/{id}")
    public ResponseEntity<College> updateCollege(@PathVariable Long id, @RequestBody College certificate) {
        College updatedCert = service.updateCollege(id, certificate);
        if (updatedCert != null) {
            return ResponseEntity.ok(updatedCert);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCollege(@PathVariable Long id) {
        service.deleteCollege(id);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/student/{studentName}")
    public List<College> getCollegesByStudent(@PathVariable String studentName) {
        return service.getCollegesByStudent(studentName);
    }
}
